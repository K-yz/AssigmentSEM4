# Project này nhằm demo việc kết nối từ JSP Servlet tới MySQL
## Bằng Tomcat10 và IntelliJ IDEA

### 1. Phần test.jsp demo kết nối all in one trong jsp - kết nối dùng Connection Pool
### 2. Phần TestServer trong servlet demo kết nối = servlet - Kết nối dùng Java thuần
### 3. Phần Student demo CRUD with MVC (sang ví dụ jsp_servlet_08)